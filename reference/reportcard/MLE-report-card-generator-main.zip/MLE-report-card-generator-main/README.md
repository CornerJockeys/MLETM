# MLE-report-card-gen
This is a report card generator for Minor League Esports Track Mania.

To use you have to clone this ropository and open report_card.py in a IDE such as VS code, install python 3, and the pillow library for python.

The Pillow library can be installed by running <pip install Pillow> in a terminal in VS code.

When you run the program it will ask for the league you are currently creating a report card for EX. AL.

Make sure you have the AL_Data.json file and AL RCD.json file spelt that exact way in a folder that is named <Match> and the week number (EX. Match 1), this is how the program will pull the data.

The program will then create 4 report cards for the chosen league if there was less than 4 matches played or subsitutions where made there will be more steps to follow.

If there were less then 4 matches played the program will not run properly currently.

The program will name the reports with the league then the two teams that played EX. AL Flames vs Spectre.
