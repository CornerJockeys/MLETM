import json
from pathlib import Path
from tkinter.font import names
import numpy as np

player_names = []

file_name = input("Enter file name: ")


def open_file(file = file_name):
    with open(file, "r") as file:
        data = json.load(file)
        return data


def strip_text(text, strip = " "):
    return text.strip(strip) if isinstance(text, str) else text

def split_list(lst, chunk_size):
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]

data = split_list(open_file(), 30)

match_1 = []
match_2 = []
match_3 = []
match_4 = []

for i in range(5):
    for j in range(30):
        if(i == 0):
            match_1.append(data[i][j])
        elif(i == 1):
            match_2.append(data[i][j])
        elif(i == 2):
            match_3.append(data[i][j])
        elif(i == 3):
            match_4.append(data[i][j])

match_1 = split_list(match_1, 6)
match_2 = split_list(match_2, 6)
match_3 = split_list(match_3, 6)
match_4 = split_list(match_4, 6)


#match 1 data

match_1_data_chunk = [[],[],[],[],[]]

for i in range(len(match_1)):
    for j in range(len(match_1[i])):
        match_1_data_chunk[i].append(match_1[i][j])

match_1_data_chunk = split_list(match_1_data_chunk, 6)

match_1_player_data = [[[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []] ]

#stays 0, map 1-5, player 1-6
#print(match_1_data_chunk[0][0][0])

for i in range(5):
    for j in range(6):
        match_1_player_data[i][j].append(match_1_data_chunk[0][i][j]['Player Name'])
        match_1_player_data[i][j].append(match_1_data_chunk[0][i][j]['Points'])
        match_1_data_chunk[0][i][j]['Best Time'] = match_1_data_chunk[0][i][j]['Best Time'].replace("1899-12-30T08:", '')
        match_1_data_chunk[0][i][j]['Best Time'] = match_1_data_chunk[0][i][j]['Best Time'].replace("Z", '')
        match_1_data_chunk[0][i][j]['Median Time'] = match_1_data_chunk[0][i][j]['Median Time'].replace("1899-12-30T08:", '')
        match_1_data_chunk[0][i][j]['Median Time'] = match_1_data_chunk[0][i][j]['Median Time'].replace("Z", '')
        match_1_player_data[i][j].append(match_1_data_chunk[0][i][j]['Best Time'])
        match_1_player_data[i][j].append(match_1_data_chunk[0][i][j]['Median Time'])
        match_1_player_data[i][j].append(round(match_1_data_chunk[0][i][j]['Rd Respawn%']*100, 2))

for i in range(len(match_1_player_data)):
    for j in range(1,len(match_1_player_data[i])):
        for i in range(5):
            if(match_1_player_data[i][j][1] > match_1_player_data[i][j-1][1]):
                temp = match_1_player_data[i][j-1]
                match_1_player_data[i][j-1] = match_1_player_data[i][j]
                match_1_player_data[i][j] = temp

match_1_output = [[], [], [], [], []]

for i in range(len(match_1_player_data)):
    for j in match_1_player_data[i]:
        #print(j)
        match_1_output[i].append(j)


match_1_team_names = [match_1_data_chunk[0][0][0]['Team 1'], match_1_data_chunk[0][0][0]['Team 2']]
match_1_team_members = [[], []]
#print(match_1_data_chunk[0][0])
for i in match_1_data_chunk[0][0]:
    if(i['Played For'] == 1):
        match_1_team_members[0].append(i['Player Name'])
    else:
        match_1_team_members[1].append(i['Player Name'])


#match 2 data

match_2_data_chunk = [[],[],[],[],[]]

for i in range(len(match_2)):
    for j in range(len(match_2[i])):
        match_2_data_chunk[i].append(match_2[i][j])

match_2_data_chunk = split_list(match_2_data_chunk, 6)

match_2_player_data = [[[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []] ]

#stays 0, map 1-5, player 1-6
#print(match_1_data_chunk[0][0][0])

for i in range(5):
    for j in range(6):
        match_2_player_data[i][j].append(match_2_data_chunk[0][i][j]['Player Name'])
        match_2_player_data[i][j].append(match_2_data_chunk[0][i][j]['Points'])
        match_2_data_chunk[0][i][j]['Best Time'] = match_2_data_chunk[0][i][j]['Best Time'].replace("1899-12-30T08:", '')
        match_2_data_chunk[0][i][j]['Best Time'] = match_2_data_chunk[0][i][j]['Best Time'].replace("Z", '')
        match_2_data_chunk[0][i][j]['Median Time'] = match_2_data_chunk[0][i][j]['Median Time'].replace("1899-12-30T08:", '')
        match_2_data_chunk[0][i][j]['Median Time'] = match_2_data_chunk[0][i][j]['Median Time'].replace("Z", '')
        match_2_player_data[i][j].append(match_2_data_chunk[0][i][j]['Best Time'])
        match_2_player_data[i][j].append(match_2_data_chunk[0][i][j]['Median Time'])
        match_2_player_data[i][j].append(round(match_2_data_chunk[0][i][j]['Rd Respawn%']*100, 2))

for i in range(len(match_2_player_data)):
    for j in range(1,len(match_2_player_data[i])):
        for i in range(5):
            if(match_2_player_data[i][j][1] > match_2_player_data[i][j-1][1]):
                temp = match_2_player_data[i][j-1]
                match_2_player_data[i][j-1] = match_2_player_data[i][j]
                match_2_player_data[i][j] = temp

match_2_output = [[], [], [], [], []]

for i in range(len(match_2_player_data)):
    for j in match_2_player_data[i]:
        #print(j)
        match_2_output[i].append(j)

match_2_team_names = [match_2_data_chunk[0][0][0]['Team 1'], match_2_data_chunk[0][0][0]['Team 2']]
match_2_team_members = [[], []]
#print(match_1_data_chunk[0][0])
for i in match_2_data_chunk[0][0]:
    if(i['Played For'] == 1):
        match_2_team_members[0].append(i['Player Name'])
    else:
        match_2_team_members[1].append(i['Player Name'])
                


#match 3 data


match_3_data_chunk = [[],[],[],[],[]]

for i in range(len(match_3)):
    for j in range(len(match_3[i])):
        match_3_data_chunk[i].append(match_3[i][j])

match_3_data_chunk = split_list(match_3_data_chunk, 6)

match_3_player_data = [[[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []] ]

for i in range(5):
    for j in range(6):
        match_3_player_data[i][j].append(match_3_data_chunk[0][i][j]['Player Name'])
        match_3_player_data[i][j].append(match_3_data_chunk[0][i][j]['Points'])
        match_3_data_chunk[0][i][j]['Best Time'] = match_3_data_chunk[0][i][j]['Best Time'].replace("1899-12-30T08:", '')
        match_3_data_chunk[0][i][j]['Best Time'] = match_3_data_chunk[0][i][j]['Best Time'].replace("Z", '')
        match_3_data_chunk[0][i][j]['Median Time'] = match_3_data_chunk[0][i][j]['Median Time'].replace("1899-12-30T08:", '')
        match_3_data_chunk[0][i][j]['Median Time'] = match_3_data_chunk[0][i][j]['Median Time'].replace("Z", '')
        match_3_player_data[i][j].append(match_3_data_chunk[0][i][j]['Best Time'])
        match_3_player_data[i][j].append(match_3_data_chunk[0][i][j]['Median Time'])
        match_3_player_data[i][j].append(round(match_3_data_chunk[0][i][j]['Rd Respawn%']*100, 2))


for i in range(len(match_3_player_data)):
    for j in range(1,len(match_3_player_data[i])):
        for i in range(5):
            if(match_3_player_data[i][j][1] > match_3_player_data[i][j-1][1]):
                temp = match_3_player_data[i][j-1]
                match_3_player_data[i][j-1] = match_3_player_data[i][j]
                match_3_player_data[i][j] = temp

match_3_output = [[], [], [], [], []]

for i in range(len(match_3_player_data)):
    for j in match_3_player_data[i]:
        #print(j)
        match_3_output[i].append(j)

match_3_team_names = [match_3_data_chunk[0][0][0]['Team 1'], match_3_data_chunk[0][0][0]['Team 2']]
match_3_team_members = [[], []]
#print(match_1_data_chunk[0][0])
for i in match_3_data_chunk[0][0]:
    if(i['Played For'] == 1):
        match_3_team_members[0].append(i['Player Name'])
    else:
        match_3_team_members[1].append(i['Player Name'])


#match 4 data

match_4_data_chunk = [[],[],[],[],[]]

for i in range(len(match_4)):
    for j in range(len(match_4[i])):
        match_4_data_chunk[i].append(match_4[i][j])

match_4_data_chunk = split_list(match_4_data_chunk, 6)

match_4_player_data = [[[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []] ]

#stays 0, map 1-5, player 1-6
#print(match_1_data_chunk[0][0][0])

for i in range(5):
    for j in range(6):
        match_4_player_data[i][j].append(match_4_data_chunk[0][i][j]['Player Name'])
        match_4_player_data[i][j].append(match_4_data_chunk[0][i][j]['Points'])
        match_4_data_chunk[0][i][j]['Best Time'] = match_4_data_chunk[0][i][j]['Best Time'].replace("1899-12-30T08:", '')
        match_4_data_chunk[0][i][j]['Best Time'] = match_4_data_chunk[0][i][j]['Best Time'].replace("Z", '')
        match_4_data_chunk[0][i][j]['Median Time'] = match_4_data_chunk[0][i][j]['Median Time'].replace("1899-12-30T08:", '')
        match_4_data_chunk[0][i][j]['Median Time'] = match_4_data_chunk[0][i][j]['Median Time'].replace("Z", '')
        match_4_player_data[i][j].append(match_4_data_chunk[0][i][j]['Best Time'])
        match_4_player_data[i][j].append(match_4_data_chunk[0][i][j]['Median Time'])
        match_4_player_data[i][j].append(round(match_4_data_chunk[0][i][j]['Rd Respawn%']*100, 2))


for i in range(len(match_4_player_data)):
    for j in range(1,len(match_4_player_data[i])):
        for i in range(5):
            if(match_4_player_data[i][j][1] > match_4_player_data[i][j-1][1]):
                temp = match_4_player_data[i][j-1]
                match_4_player_data[i][j-1] = match_4_player_data[i][j]
                match_4_player_data[i][j] = temp

match_4_output = [[], [], [], [], []]

for i in range(len(match_4_player_data)):
    for j in match_4_player_data[i]:
        #print(j)
        match_4_output[i].append(j)


match_4_team_names = [match_4_data_chunk[0][0][0]['Team 1'], match_4_data_chunk[0][0][0]['Team 2']]
match_4_team_members = [[], []]
#print(match_1_data_chunk[0][0])
for i in match_4_data_chunk[0][0]:
    if(i['Played For'] == 1):
        match_4_team_members[0].append(i['Player Name'])
    else:
        match_4_team_members[1].append(i['Player Name'])
