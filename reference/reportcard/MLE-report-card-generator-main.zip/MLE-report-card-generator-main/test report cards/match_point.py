import json


player_names = []

file_name_start = input("Enter league: ")

match = input("Input match week: ")

file_name = "Match " + match + "/" + file_name_start+'_Data.json'

maps = {

    #AL maps
    "X3ftQtwm4ZRzKy__8mG2XERu5gd": "Calaboose",
    "CoetQve2spyG8rVxnOKssXltbZa": "Emily",
    "A0wKKFkCcelPB8XdGPjCPt3nNu": "Zanzibar",
    "q8FBp3dSzAftMGWLDB786ctTund": "Anglioni",
    "JxXG4fed5IdgmVsKTibWWW1pSt4": "Bleize",

    #ML/CL maps
    "8jfetYFElsrYtXiAZWizCcfObAb": "Calaboose",
    "o_XM5k6nOvYLItQq90RiUSsQ8Z7": "Emily",
    "2Gde9hBpW757HWHR6DaVKyfkHE4": "Zanzibar",
    "0CbeJt43ic92_FsErOyltuAiGia": "Anglioni",
    "zpcDq1D_YW7_z_XAdOsYEZ0558g": "Bleize"
}


def open_file(file = file_name):
    with open(file, "r") as file:
        data = json.load(file)
        return data

data = open_file()

def strip_text(text, strip = " "):
    return text.strip(strip) if isinstance(text, str) else text

def split_list(lst, chunk_size):
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]

def shorten_list(list):
    temp_list = []
    for i in list:
        temp_list.append(i[0])
    return temp_list

def maps_points(list):
    output = []
    for i in list:
        if(i[1] == 1):
            output.append([maps[i[0]]])
    return output

def match_scores(input):
    print(input)
    Zanzibar = 0
    Bleize = 0
    Anglioni = 0
    Calaboose = 0
    Emily = 0
    output_list = []
    for i in input:
        if(i[0] == 'Zanzibar'):
            Zanzibar += 1
        elif(i[0] == 'Bleize'):
            Bleize += 1
        elif(i[0] == 'Anglioni'):
            Anglioni += 1
        elif(i[0] == 'Calaboose'):
            Calaboose += 1
        elif(i[0] == 'Emily'):
            Emily += 1
    output_list.append(Calaboose)
    output_list.append(Anglioni)
    output_list.append(Bleize)
    output_list.append(Emily)
    output_list.append(Zanzibar)
    return output_list

data = split_list(data, 1)

#print(data[0])



abv_teams = {
    "HUR": "Hurricanes",
    "SAB": "Sabres",
    "FLA": "Flames",
    "JET": "JETS",
    "DOD": "Dodgers",
    "WIZ": "Wizards",
    "HIV": "Hive",
    "SPE": "Spectre",
    " SP": "Spectre",
    " HU": "Hurricanes"
}

teams = data[0][0]['Match ID']

teams = list(teams.replace(" VS ", '').replace(" M1 ", ''))

league = teams[7] + teams[8]

teams = []

#print(data)

for i in data:
    if(abv_teams[list(i[0]['Match ID'])[0] + list(i[0]['Match ID'])[1] + list(i[0]['Match ID'])[2]] not in teams):
        teams.append(abv_teams[list(i[0]['Match ID'])[0] + list(i[0]['Match ID'])[1] + list(i[0]['Match ID'])[2]])
    elif(abv_teams[list(i[0]['Match ID'])[7] + list(i[0]['Match ID'])[8] + list(i[0]['Match ID'])[9]] not in teams):
        teams.append(abv_teams[list(i[0]['Match ID'])[7] + list(i[0]['Match ID'])[8] + list(i[0]['Match ID'])[9]])


teams = split_list(teams, 1)

#stores player team, map played, and if won round on that map
test_list = []

for i in range(1,len(data)):
    test_list.append([data[i][0]['Team Name'], data[i][0]['Map UID'], data[i][0]['Round Win?']])

Flames = []
Hurricanes = []
Spectre = []
Wizards = []
Sabres = []
Jets = []
Hive = []
Dodgers = []


for i in test_list:
    #print(i[0])
    if(i[0] == 'Flames'):
        Flames.append([i[1], i[2]])
    elif(i[0] == 'Hurricanes'):
        Hurricanes.append([i[1], i[2]])
    elif(i[0] == 'Spectre'):
        Spectre.append([i[1], i[2]])
    elif(i[0] == 'Wizards'):
        Wizards.append([i[1], i[2]])
    elif(i[0] == 'Sabres'):
        Sabres.append([i[1], i[2]])
    elif(i[0] == 'Jets'):
        Jets.append([i[1], i[2]])
    elif(i[0] == 'Hive'):
        Hive.append([i[1], i[2]])
    elif(i[0] == 'Dodgers'):
        Dodgers.append([i[1], i[2]])

Flames = split_list(Flames, 3)
Hurricanes = split_list(Hurricanes, 3)
Spectre = split_list(Spectre, 3)
Wizards = split_list(Wizards, 3)
Sabre = split_list(Sabres, 3)
Jets = split_list(Jets, 3)
Hive = split_list(Hive, 3)
Dodgers = split_list(Dodgers, 3)


Flames_list = shorten_list(Flames)
Hurricanes_list = shorten_list(Hurricanes)
Spectre_list = shorten_list(Spectre)
Wizards_list = shorten_list(Wizards)
Sabres_list = shorten_list(Sabre)
Jets_list = shorten_list(Jets)
Hive_list = shorten_list(Hive)
Dodgers_list = shorten_list(Dodgers)

def get_team_list(name):
    if(name == 'Flames'):
        return Flames_list
    elif(name == 'Spectre'):
        return Spectre_list
    elif(name == 'Wizards'):
        return Wizards_list
    elif(name == 'Sabres'):
        return Sabres_list
    elif(name == 'Jets'):
        return Jets_list
    elif(name == 'Hive'):
        return Hive_list
    elif(name == 'Hurricanes'):
        return Hurricanes_list
    else:
        return Dodgers_list

def make_match(team_one, team_two):
    output_list = []
    map_order = [4, 2, 3, 1, 5]
    for i in map_order:
        output_list.append([team_one[i-1], team_two[i-1]])
    return output_list

#5-4  5-1   5-0   5-1   5-1   


#print(Hurricanes_list)

#print(match_scores(maps_points(get_team_list('Sabres'))))
print(make_match(match_scores(maps_points(get_team_list('Jets'))), match_scores(maps_points(get_team_list('Spectre')))))


#print(len(Flames_list))