from PIL import Image, ImageDraw, ImageFont

# Fonts (you'll need a .ttf file)
font_path = "Industry Black.otf"
font_title = ImageFont.truetype(font_path, 40)
font_text = ImageFont.truetype(font_path, 20)
font_team_names = ImageFont.truetype(font_path, 30)


import json


player_names = []

file_name_start = input("Enter leauge: ")
match = input("Input match week: ")

file_name = "Match " + match + "/" + file_name_start+' Raw Data.json'

maps = {
    #AL maps
    "X3ftQtwm4ZRzKy__8mG2XERu5gd": "Calaboose",
    "CoetQve2spyG8rVxnOKssXltbZa": "Emily",
    "A0wKKFkCcelPB8XdGPjCPt3nNu": "Zanzibar",
    "q8FBp3dSzAftMGWLDB786ctTund": "Anglioni",
    "JxXG4fed5IdgmVsKTibWWW1pSt4": "Bleize",

    #ML/CL maps
    "8jfetYFElsrYtXiAZWizCcfObAb": "Calaboose",
    "o_XM5k6nOvYLItQq90RiUSsQ8Z7": "Emily",
    "2Gde9hBpW757HWHR6DaVKyfkHE4": "Zanzibar",
    "0CbeJt43ic92_FsErOyltuAiGia": "Anglioni",
    "zpcDq1D_YW7_z_XAdOsYEZ0558g": "Bleize"
}


def open_file(file = file_name):
    with open(file, "r") as file:
        data = json.load(file)
        return data

data = open_file()

def strip_text(text, strip = " "):
    return text.strip(strip) if isinstance(text, str) else text

def split_list(lst, chunk_size):
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]

def shorten_list(list):
    temp_list = []
    for i in list:
        temp_list.append(i[0])
    return temp_list

def maps_points(list):
    output = []
    for i in list:
        if(i[1] == 1):
            output.append([maps[i[0]]])
    return output

def match_scores(input):
    Zanzibar = 0
    Bleize = 0
    Anglioni = 0
    Calaboose = 0
    Emily = 0
    output_list = []
    for i in input:
        if(i[0] == 'Zanzibar'):
            Zanzibar += 1
        elif(i[0] == 'Bleize'):
            Bleize += 1
        elif(i[0] == 'Anglioni'):
            Anglioni += 1
        elif(i[0] == 'Calaboose'):
            Calaboose += 1
        elif(i[0] == 'Emily'):
            Emily += 1
    output_list.append(Calaboose)
    output_list.append(Anglioni)
    output_list.append(Bleize)
    output_list.append(Emily)
    output_list.append(Zanzibar)
    return output_list

data = split_list(data, 1)

#print(data[0])



abv_teams = {
    "HUR": "Hurricanes",
    "SAB": "Sabres",
    "FLA": "Flames",
    "JET": "JETS",
    "DOD": "Dodgers",
    "WIZ": "Wizards",
    "HIV": "Hive",
    "SPE": "Spectre",
    " SP": "Spectre",
    " HU": "Hurricanes",
    " DO": "Dodgers"
}

teams = data[0][0]['Match ID']

teams = list(teams.replace(" VS ", '').replace(" M1 ", ''))

league = teams[7] + teams[8]

teams = []


for i in data:
    if(abv_teams[list(i[0]['Match ID'])[0] + list(i[0]['Match ID'])[1] + list(i[0]['Match ID'])[2]] not in teams):
        teams.append(abv_teams[list(i[0]['Match ID'])[0] + list(i[0]['Match ID'])[1] + list(i[0]['Match ID'])[2]])
    elif(abv_teams[list(i[0]['Match ID'])[7] + list(i[0]['Match ID'])[8] + list(i[0]['Match ID'])[9]] not in teams):
        teams.append(abv_teams[list(i[0]['Match ID'])[7] + list(i[0]['Match ID'])[8] + list(i[0]['Match ID'])[9]])


teams = split_list(teams, 1)

#stores player team, map played, and if won round on that map
test_list = []

for i in range(1,len(data)):
    test_list.append([data[i][0]['Team Name'], data[i][0]['Map UID'], data[i][0]['Round Win?']])

Flames = []
Hurricanes = []
Spectre = []
Wizards = []
Sabres = []
Jets = []
Hive = []
Dodgers = []



for i in test_list:
    #print(i[0])
    if(i[0] == 'Flames'):
        Flames.append([i[1], i[2]])
    elif(i[0] == 'Hurricanes'):
        Hurricanes.append([i[1], i[2]])
    elif(i[0] == 'Spectre'):
        Spectre.append([i[1], i[2]])
    elif(i[0] == 'Wizards'):
        Wizards.append([i[1], i[2]])
    elif(i[0] == 'Sabres'):
        Sabres.append([i[1], i[2]])
    elif(i[0] == 'Jets'):
        Jets.append([i[1], i[2]])
    elif(i[0] == 'Hive'):
        Hive.append([i[1], i[2]])
    elif(i[0] == 'Dodgers'):
        Dodgers.append([i[1], i[2]])

Flames = split_list(Flames, 3)
Hurricanes = split_list(Hurricanes, 3)
Spectre = split_list(Spectre, 3)
Wizards = split_list(Wizards, 3)
Sabres = split_list(Sabres, 3)
Jets = split_list(Jets, 3)
Hive = split_list(Hive, 3)
Dodgers = split_list(Dodgers, 3)

Flames_list = shorten_list(Flames)
Hurricanes_list = shorten_list(Hurricanes)
Spectre_list = shorten_list(Spectre)
Wizards_list = shorten_list(Wizards)
Sabres_list = shorten_list(Sabres)
Jets_list = shorten_list(Jets)
Hive_list = shorten_list(Hive)
Dodgers_list = shorten_list(Dodgers)

def get_team_list(name):
    if(name == 'Flames'):
        return Flames_list
    elif(name == 'Spectre'):
        return Spectre_list
    elif(name == 'Wizards'):
        return Wizards_list
    elif(name == 'Sabres'):
        return Sabres_list
    elif(name == 'Jets'):
        return Jets_list
    elif(name == 'Hive'):
        return Hive_list
    elif(name == 'Hurricanes'):
        return Hurricanes_list
    else:
        return Dodgers_list

def make_match(team_one, team_two):
    output_list = []
    map_order = [5, 1, 4, 3, 2]
    for i in map_order:
        output_list.append([team_one[i-1], team_two[i-1]])
    return output_list



import json
from pathlib import Path
from tkinter.font import names
import numpy as np

player_names = []

file_name = "Match " + match + "/" + file_name_start+' RCD.json'


def open_file(file = file_name):
    with open(file, "r") as file:
        data = json.load(file)
        return data


def strip_text(text, strip = " "):
    return text.strip(strip) if isinstance(text, str) else text

def split_list(lst, chunk_size):
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]

data = split_list(open_file(), 30)

match_1 = []
match_2 = []
match_3 = []
match_4 = []

for i in range(5):
    for j in range(30):
        if(i == 0):
            match_1.append(data[i][j])
        elif(i == 1):
            match_2.append(data[i][j])
        elif(i == 2):
            match_3.append(data[i][j])
        elif(i == 3):
            match_4.append(data[i][j])

match_1 = split_list(match_1, 6)
match_2 = split_list(match_2, 6)
match_3 = split_list(match_3, 6)
match_4 = split_list(match_4, 6)

#match 1 data

match_1_data_chunk = [[],[],[],[],[]]

for i in range(len(match_1)):
    for j in range(len(match_1[i])):
        match_1_data_chunk[i].append(match_1[i][j])

match_1_data_chunk = split_list(match_1_data_chunk, 6)

match_1_player_data = [[[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []] ]

#stays 0, map 1-5, player 1-6
#print(match_1_data_chunk[0][0][0])

for i in range(5):
    for j in range(6):
        match_1_player_data[i][j].append(match_1_data_chunk[0][i][j]['Player Name'])
        match_1_player_data[i][j].append(match_1_data_chunk[0][i][j]['Points'])
        match_1_data_chunk[0][i][j]['Best Time'] = match_1_data_chunk[0][i][j]['Best Time'].replace("1899-12-30T08:", '')
        match_1_data_chunk[0][i][j]['Best Time'] = match_1_data_chunk[0][i][j]['Best Time'].replace("1899-12-30T07:59:59.999", '0')
        match_1_data_chunk[0][i][j]['Best Time'] = match_1_data_chunk[0][i][j]['Best Time'].replace("Z", '')
        match_1_data_chunk[0][i][j]['Median Time'] = match_1_data_chunk[0][i][j]['Median Time'].replace("1899-12-30T08:", '')
        match_1_data_chunk[0][i][j]['Median Time'] = match_1_data_chunk[0][i][j]['Median Time'].replace("Z", '')
        match_1_player_data[i][j].append(match_1_data_chunk[0][i][j]['Best Time'])
        match_1_player_data[i][j].append(match_1_data_chunk[0][i][j]['Median Time'])
        match_1_player_data[i][j].append(round(match_1_data_chunk[0][i][j]['Rd Respawn%']*100, 2))

for i in range(len(match_1_player_data)):
    for j in range(1,len(match_1_player_data[i])):
        for i in range(5):
            if(match_1_player_data[i][j][1] > match_1_player_data[i][j-1][1]):
                temp = match_1_player_data[i][j-1]
                match_1_player_data[i][j-1] = match_1_player_data[i][j]
                match_1_player_data[i][j] = temp

match_1_output = [[], [], [], [], []]

for i in range(len(match_1_player_data)):
    for j in match_1_player_data[i]:
        #print(j)
        match_1_output[i].append(j)


match_1_team_names = [match_1_data_chunk[0][0][0]['Team 1'], match_1_data_chunk[0][0][0]['Team 2']]
match_1_team_members = [[], []]
#print(match_1_data_chunk[0][0])
for i in match_1_data_chunk[0][0]:
    if(i['Played For'] == 1):
        match_1_team_members[0].append(i['Player Name'])
    else:
        match_1_team_members[1].append(i['Player Name'])


#match 2 data

match_2_data_chunk = [[],[],[],[],[]]

for i in range(len(match_2)):
    for j in range(len(match_2[i])):
        match_2_data_chunk[i].append(match_2[i][j])

match_2_data_chunk = split_list(match_2_data_chunk, 6)

match_2_player_data = [[[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []] ]

#stays 0, map 1-5, player 1-6
#print(match_1_data_chunk[0][0][0])

for i in range(5):
    for j in range(6):
        match_2_player_data[i][j].append(match_2_data_chunk[0][i][j]['Player Name'])
        match_2_player_data[i][j].append(match_2_data_chunk[0][i][j]['Points'])
        match_2_data_chunk[0][i][j]['Best Time'] = match_2_data_chunk[0][i][j]['Best Time'].replace("1899-12-30T08:", '')
        match_2_data_chunk[0][i][j]['Best Time'] = match_2_data_chunk[0][i][j]['Best Time'].replace("1899-12-30T07:59:59.999", '0')
        match_2_data_chunk[0][i][j]['Best Time'] = match_2_data_chunk[0][i][j]['Best Time'].replace("Z", '')
        match_2_data_chunk[0][i][j]['Median Time'] = match_2_data_chunk[0][i][j]['Median Time'].replace("1899-12-30T08:", '')
        match_2_data_chunk[0][i][j]['Median Time'] = match_2_data_chunk[0][i][j]['Median Time'].replace("Z", '')
        match_2_player_data[i][j].append(match_2_data_chunk[0][i][j]['Best Time'])
        match_2_player_data[i][j].append(match_2_data_chunk[0][i][j]['Median Time'])
        match_2_player_data[i][j].append(round(match_2_data_chunk[0][i][j]['Rd Respawn%']*100, 2))

for i in range(len(match_2_player_data)):
    for j in range(1,len(match_2_player_data[i])):
        for i in range(5):
            if(match_2_player_data[i][j][1] > match_2_player_data[i][j-1][1]):
                temp = match_2_player_data[i][j-1]
                match_2_player_data[i][j-1] = match_2_player_data[i][j]
                match_2_player_data[i][j] = temp

match_2_output = [[], [], [], [], []]

for i in range(len(match_2_player_data)):
    for j in match_2_player_data[i]:
        #print(j)
        match_2_output[i].append(j)

match_2_team_names = [match_2_data_chunk[0][0][0]['Team 1'], match_2_data_chunk[0][0][0]['Team 2']]
match_2_team_members = [["Robbalobb", "AkulTM"], []]
#print(match_1_data_chunk[0][0])
for i in match_2_data_chunk[0][0]:
    if(i['Played For'] == 1):
        match_2_team_members[0].append(i['Player Name'])
    else:
        match_2_team_members[1].append(i['Player Name'])
                


#match 3 data


match_3_data_chunk = [[],[],[],[],[]]

for i in range(len(match_3)):
    for j in range(len(match_3[i])):
        match_3_data_chunk[i].append(match_3[i][j])

match_3_data_chunk = split_list(match_3_data_chunk, 6)

match_3_player_data = [[[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []] ]

#stays 0, map 1-5, player 1-6
#print(match_1_data_chunk[0][0][0])

for i in range(5):
    for j in range(6):
        match_3_player_data[i][j].append(match_3_data_chunk[0][i][j]['Player Name'])
        match_3_player_data[i][j].append(match_3_data_chunk[0][i][j]['Points'])
        match_3_data_chunk[0][i][j]['Best Time'] = match_3_data_chunk[0][i][j]['Best Time'].replace("1899-12-30T08:", '')
        match_3_data_chunk[0][i][j]['Best Time'] = match_3_data_chunk[0][i][j]['Best Time'].replace("1899-12-30T07:59:59.999", '0')
        match_3_data_chunk[0][i][j]['Best Time'] = match_3_data_chunk[0][i][j]['Best Time'].replace("Z", '')
        match_3_data_chunk[0][i][j]['Median Time'] = match_3_data_chunk[0][i][j]['Median Time'].replace("1899-12-30T08:", '')
        match_3_data_chunk[0][i][j]['Median Time'] = match_3_data_chunk[0][i][j]['Median Time'].replace("Z", '')
        match_3_player_data[i][j].append(match_3_data_chunk[0][i][j]['Best Time'])
        match_3_player_data[i][j].append(match_3_data_chunk[0][i][j]['Median Time'])
        match_3_player_data[i][j].append(round(match_3_data_chunk[0][i][j]['Rd Respawn%']*100, 2))


for i in range(len(match_3_player_data)):
    for j in range(1,len(match_3_player_data[i])):
        for i in range(5):
            if(match_3_player_data[i][j][1] > match_3_player_data[i][j-1][1]):
                temp = match_3_player_data[i][j-1]
                match_3_player_data[i][j-1] = match_3_player_data[i][j]
                match_3_player_data[i][j] = temp

match_3_output = [[], [], [], [], []]

for i in range(len(match_3_player_data)):
    for j in match_3_player_data[i]:
        #print(j)
        match_3_output[i].append(j)

match_3_team_names = [match_3_data_chunk[0][0][0]['Team 1'], match_3_data_chunk[0][0][0]['Team 2']]
match_3_team_members = [[], []]
#print(match_1_data_chunk[0][0])
for i in match_3_data_chunk[0][0]:
    if(i['Played For'] == 1):
        match_3_team_members[0].append(i['Player Name'])
    else:
        match_3_team_members[1].append(i['Player Name'])


#match 4 data

match_4_data_chunk = [[],[],[],[],[]]

for i in range(len(match_4)):
    for j in range(len(match_4[i])):
        match_4_data_chunk[i].append(match_4[i][j])

match_4_data_chunk = split_list(match_4_data_chunk, 6)

match_4_player_data = [[[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []], [[], [], [], [], [], []] ]

#stays 0, map 1-5, player 1-6
#print(match_1_data_chunk[0][0][0])

for i in range(5):
    for j in range(6):
        match_4_player_data[i][j].append(match_4_data_chunk[0][i][j]['Player Name'])
        match_4_player_data[i][j].append(match_4_data_chunk[0][i][j]['Points'])
        match_4_data_chunk[0][i][j]['Best Time'] = match_4_data_chunk[0][i][j]['Best Time'].replace("1899-12-30T08:", '')
        match_4_data_chunk[0][i][j]['Best Time'] = match_4_data_chunk[0][i][j]['Best Time'].replace("1899-12-30T07:59:59.999", '0')
        match_4_data_chunk[0][i][j]['Best Time'] = match_4_data_chunk[0][i][j]['Best Time'].replace("Z", '')
        match_4_data_chunk[0][i][j]['Median Time'] = match_4_data_chunk[0][i][j]['Median Time'].replace("1899-12-30T08:", '')
        match_4_data_chunk[0][i][j]['Median Time'] = match_4_data_chunk[0][i][j]['Median Time'].replace("Z", '')
        match_4_player_data[i][j].append(match_4_data_chunk[0][i][j]['Best Time'])
        match_4_player_data[i][j].append(match_4_data_chunk[0][i][j]['Median Time'])
        match_4_player_data[i][j].append(round(match_4_data_chunk[0][i][j]['Rd Respawn%']*100, 2))


for i in range(len(match_4_player_data)):
    for j in range(1,len(match_4_player_data[i])):
        for i in range(5):
            if(match_4_player_data[i][j][1] > match_4_player_data[i][j-1][1]):
                temp = match_4_player_data[i][j-1]
                match_4_player_data[i][j-1] = match_4_player_data[i][j]
                match_4_player_data[i][j] = temp

match_4_output = [[], [], [], [], []]

for i in range(len(match_4_player_data)):
    for j in match_4_player_data[i]:
        #print(j)
        match_4_output[i].append(j)


match_4_team_names = [match_4_data_chunk[0][0][0]['Team 1'], match_4_data_chunk[0][0][0]['Team 2']]
match_4_team_members = [[], []]
#print(match_1_data_chunk[0][0])
for i in match_4_data_chunk[0][0]:
    if(i['Played For'] == 1):
        match_4_team_members[0].append(i['Player Name'])
    else:
        match_4_team_members[1].append(i['Player Name'])

# Create blank canvas
    image_size = (1350, 1290)
    img = Image.new('RGB', image_size, color=(20, 20, 30))
    draw = ImageDraw.Draw(img)

def create_centered_text_image(offset = (0, 0), 
                               text ="",
                               image_size=(1200, 700), 
                               font = None, 
                               color = (255, 255, 255)):
    draw = ImageDraw.Draw(img)

    # Get text bounding box
    bbox = draw.textbbox((0, 0), text = text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]

    # Calculate centered position
    #print("runnin")
    x = (image_size[0] - text_width) / 2
    y = (image_size[1] - text_height) / 2

    # Draw text
    draw.text((x+offset[0], y+offset[1]), text, font=font, fill=color)

    return img

def paste_png_onto_image(background, png_path, position=(0, 0), angle = 0):
    # Open background and PNG images
    overlay = Image.open(png_path).convert("RGBA")

    if(angle == 90):
        overlay = overlay.transpose(Image.ROTATE_90)

    # Paste PNG onto background using alpha channel as mask
    background.paste(overlay, position, overlay)

def create_rectangle_image(image_path,
                            rect_coords=(50, 50, 250, 150),
                            fill_color=None,  # None = transparent fill
                            outline_color=(0, 0, 0),
                            outline_width=0):
    # Create a drawing object
    draw = ImageDraw.Draw(image_path)
    # Draw the rectangle
    draw.rectangle(rect_coords, fill=fill_color, outline=outline_color, width=outline_width)
    return img

def create_hort_line(image_path,
                line_hight=0,
                color=(50, 55, 70),  # None = transparent fill
                line_width = 1):
    # Create a drawing object
    draw = ImageDraw.Draw(image_path)
    # Draw the line
    y = line_hight
    draw.line((0,y, 1400,y), fill=color, width=5)
    return img

def create_vert_line(image_path,
                line_x = 0,
                color=(50, 55, 70),  # None = transparent fill
                line_width = 1):
    # Create a drawing object
    draw = ImageDraw.Draw(image_path)
    # Draw the line
    x = line_x
    draw.line((x,440, x,1475), fill=color, width=5)
    return img

def ms_to_sec(ms):
    minutes = ms // 60000
    seconds = (ms % 60000) / 1000
    return str(minutes)+':'+str(seconds)

def generate_image(player_info = None, 
                       team_names = None, 
                       team_members = None,
                       ):
    draw.rectangle([(0, 0), img.size], fill=(50, 50, 50))


    paste_png_onto_image(img, "text backgrounds/MLETM_Gradient.png")

    paste_png_onto_image(img, "banners/MLE.png", (0, 0))

    player_data = player_info


    #MLE match specfic data
    map_names = ["Zanzibar", "Calaboose", "Emily", "Belize", "Anglioni"]

    #["Calaboose", "Emily", "Anglioni", "Zanzibar", "Belize"]

    teams = team_names
    #print(teams)

    team_one = team_members[0]

    team_two = team_members[1]

    match_results = make_match(match_scores(maps_points(get_team_list(teams[0]))), match_scores(maps_points(get_team_list(teams[1]))))


    for i in range(len(map_names)):
        if(i == 0):
           paste_png_onto_image(img, "map names/" + map_names[i] + ".png", (0, 290), 90)
        elif(i == 1):
            paste_png_onto_image(img, "map names/" + map_names[i] + ".png", (0, 490), 90)
        elif(i == 2):
            paste_png_onto_image(img, "map names/" + map_names[i] + ".png", (0, 690), 90)
        elif(i == 3):
            paste_png_onto_image(img, "map names/" + map_names[i] + ".png", (0, 890), 90)
        elif (i==4):
            paste_png_onto_image(img, "map names/" + map_names[i] + ".png", (0, 1090), 90)


            paste_png_onto_image(img, "banners/" + teams[0] + ".png", (106, 178))
            paste_png_onto_image(img, "text backgrounds/stats_background.png", (106, 248))

            paste_png_onto_image(img, "banners/" + teams[1] + ".png", (798, 178))
            paste_png_onto_image(img, "text backgrounds/stats_background.png", (728, 248))

    y = 290

    for i in range(5):

        paste_png_onto_image(img, "text backgrounds/stats_text_background.png", (106, y))
        paste_png_onto_image(img, "text backgrounds/stats_text_background.png", (728, y))

        y += 200

    x = -450
    player_stats_header_font = ImageFont.truetype(font_path, 17)
    create_centered_text_image((x, -378), "Player names",image_size, player_stats_header_font, "white")
    create_centered_text_image((x+115, -378), "Points",image_size, player_stats_header_font, "white")
    create_centered_text_image((x+200, -378), "Best time",image_size, player_stats_header_font, "white")
    create_centered_text_image((x+305, -378),"Median time", image_size, player_stats_header_font, "white")
    create_centered_text_image((x+410, -378),"Respawn %", image_size, player_stats_header_font, "white")

    x = 190
    create_centered_text_image((x, -378), "Player names",image_size, player_stats_header_font, "white")
    create_centered_text_image((x+115, -378), "Points",image_size, player_stats_header_font, "white")
    create_centered_text_image((x+200, -378), "Best time",image_size, player_stats_header_font, "white")
    create_centered_text_image((x+305, -378),"Median time", image_size, player_stats_header_font, "white")
    create_centered_text_image((x+410, -378),"Respawn %", image_size, player_stats_header_font, "white")


    x = -450
    # Draw rows
    y_1 = -325
    y_2 = -325
    player_stats_font = ImageFont.truetype(font_path, 18)
    for i in range(len(player_data)):
        for name, points, time, average_time, respawn in player_data[i]:
            if(name in team_one):
                #print(name)
                create_centered_text_image((x, y_1), name,image_size, player_stats_font, "white")
                create_centered_text_image((x+115, y_1), str(points),image_size, player_stats_font, "white")
                create_centered_text_image((x+200, y_1),time, image_size, player_stats_font, "white")
                create_centered_text_image((x+305, y_1), average_time,image_size, player_stats_font, "white")
                create_centered_text_image((x+410, y_1), str(respawn),image_size, player_stats_font, "white")
                y_1 += 66.5
            elif(name in team_two):
                x = 190
                #print(name)
                create_centered_text_image((x, y_2), name,image_size, player_stats_font, "white")
                create_centered_text_image((x+115, y_2), str(points),image_size, player_stats_font, "white")
                create_centered_text_image((x+200, y_2),time, image_size, player_stats_font, "white")
                create_centered_text_image((x+305, y_2), average_time,image_size, player_stats_font, "white")
                create_centered_text_image((x+410, y_2), str(respawn),image_size, player_stats_font, "white")
                y_2 += 66.5
                #print("flamily")
            x = -450


    map_results_font = ImageFont.truetype(font_path, 40)
    y = -263
    for i in match_results:

        create_centered_text_image((40, y), (str(i[0]) + ' : '),image_size, map_results_font, "white")
        create_centered_text_image((82, y),str(i[1]), image_size, map_results_font, "white")

        y += 200
    match_results_font = ImageFont.truetype(font_path, 50)
    Final_number = ''
    count_1 = 0
    count_2 = 0
    print(match_results)
    for i in match_results:
        if(i[0] > i[1]):
            count_1 +=1
        else:
            count_2 +=1
    Final_number += str(count_1) + " : " +str(count_2)

    print(Final_number)
        
    create_centered_text_image((51, -440), Final_number , image_size, match_results_font, "white")

    #img.show()  # Opens in default image viewer
    img.save(league + ' ' + team_names[0] + " VS " + team_names[1] + ' ' + file_name_start +  ".png", format="PNG")


generate_image(match_1_player_data, match_1_team_names, match_1_team_members)
generate_image(match_2_player_data, match_2_team_names, match_2_team_members)
generate_image(match_3_player_data, match_3_team_names, match_3_team_members)
generate_image(match_4_player_data, match_4_team_names, match_4_team_members)
print("Done")

