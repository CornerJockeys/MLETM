from PIL import Image, ImageDraw, ImageFont
import json
import datetime


# Fonts (you'll need a .ttf file)
font_path = "Industry Black.otf"
font_title = ImageFont.truetype(font_path, 40)
font_text = ImageFont.truetype(font_path, 20)
font_team_names = ImageFont.truetype(font_path, 30)

#taking user input
#league = input("Enter leauge: ")
#match = input("Input match week: ")
league = 'AL'
match = '2'

#adjusting the input data to pull json file
start_file_name = league + " Data" + "/" + league
rcd_data = start_file_name + " RCD.json"
raw_data = start_file_name + " Raw Data.json"

#map UIDs
map_uid = {
    #AL maps
    "X3ftQtwm4ZRzKy__8mG2XERu5gd": "Calaboose",
    "CoetQve2spyG8rVxnOKssXltbZa": "Emily",
    "A0wKKFkCcelPB8XdGPjCPt3nNu": "Zanzibar",
    "q8FBp3dSzAftMGWLDB786ctTund": "Anglioni",
    "JxXG4fed5IdgmVsKTibWWW1pSt4": "Bleize",

    #ML/CL maps
    "8jfetYFElsrYtXiAZWizCcfObAb": "Calaboose",
    "o_XM5k6nOvYLItQq90RiUSsQ8Z7": "Emily",
    "2Gde9hBpW757HWHR6DaVKyfkHE4": "Zanzibar",
    "0CbeJt43ic92_FsErOyltuAiGia": "Anglioni",
    "zpcDq1D_YW7_z_XAdOsYEZ0558g": "Bleize"
}

abv_teams = {
    "HUR": "Hurricanes",
    "SAB": "Sabres",
    "FLA": "Flames",
    "JETS": "JETS",
    "DOD": "Dodgers",
    "WIZ": "Wizards",
    "HIVE": "Hive",
    "SPE": "Spectre",
}

map_names = ["Calaboose", 'Anglioni', 'Belize', 'Emily', 'Zanzibar', 'Battery', 'Whatever', 'Skrrrt', 'Nirvana', 'Melodrama']

map_orders = [[1, 4, 2, 5, 3], [4, 2, 3, 1, 5], [5, 1, 4, 3, 2], [2, 3, 5, 4, 1], [6, 9, 7, 10, 8], [9, 7, 8, 6, 10], [10, 6, 9, 8, 7], [7, 8, 10, 9, 6]]

def open_file(file):
    with open(file, "r") as file:
        data = json.load(file)
        return data

def strip_text(text, strip = " "):
    return text.strip(strip) if isinstance(text, str) else text

def split_list(lst, chunk_size):
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]

def clean_data(input_data):
    output = []
    for i in input_data:
        if('M' + match in i['Match ID'] and i['Match ID'] != ''):
            output.append(i)
    return output

def get_match_data(input_list):
    output = []
    for i in input_list:
        if('M' + match in i['Match ID']):
            output.append(i)
    return output

def split_matches(input_list, num_of_matches):
    output = [[], [], [], []]
    for i in range(num_of_matches):
        output[i] = input_list[i]
    return output

rcd_data = get_match_data(clean_data(open_file(rcd_data)))

raw_data = get_match_data(clean_data(open_file(raw_data)))

num_of_matches = len(rcd_data) // 30

rcd_data = split_list(rcd_data, 30)

#print(rcd_data[0])

matches = []

matches = split_matches(rcd_data, num_of_matches)

def generate_images(match_data,
                    
                    